<div class="wptouch-desktop-switch" style="position: static; z-index:1000; padding-top: 10px; padding-bottom: 40px; font-size: 120%; text-align: center; font-weight: bold; line-height: 150%">
	<?php _e( 'Desktop Version', 'wptouch-pro' ); ?> | <a href="<?php wptouch_the_desktop_switch_link(); ?>" rel="nofollow"><?php _e( 'Switch To Mobile Version', 'wptouch-pro' ); ?></a>
</div>