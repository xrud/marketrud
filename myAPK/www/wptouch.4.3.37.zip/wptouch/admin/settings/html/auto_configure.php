<div class="new-in-four">
	<img src="<?php echo WPTOUCH_ADMIN_URL; ?>/images/auto-config.jpg" alt="menu setup icon with phone and graphic" />
	<?php
		echo '<p>' . sprintf( __( 'This extension doesn’t currently require configuration. All of its settings are inherited from your WPtouch Pro configuration automatically.', 'wptouch-pro' ), '<br />', '<em>',  '</em>' ) . '</p>';
	?>
</div>