<div data-form-action="http://wptouch.createsend.com/t/t/s/xurhlk/" data-form-method="post" id="subForm" class="newsletter-subscribe-form js-create-form">
    <table>
        <tr>
            <td><label for="fieldName">Name</label></td>
            <td><input id="fieldName" name="cm-name" type="text" /></td>
        </tr>
        <tr>
            <td><label for="fieldEmail">Email*</label></td>
            <td><input id="fieldEmail" name="cm-xurhlk-xurhlk" type="email" class="js-required" required /></td>
        </tr>
        <tr>
            <td class="submit-button-container">
                <button type="submit" class="js-form-submit">Subscribe</button>
            </td>
        </tr>
    </table>
</div>
